
<!-- echo $curr_visitor;-->
<div class="col-md-3 col-sm-6 col-xs-12">
  <div class="info-box">
    <span class="info-box-icon bg-aqua"><i class="fa fa-users"></i></span>
      <div class="info-box-content">
        <span class="info-box-text">Total</span>
        <span class="info-box-text">User</span>
        <span class="info-box-number"></small><?php echo $jml_user;?></span>
      </div>

    </div>
  </div>

  <div class="col-md-3 col-sm-6 col-xs-12">
    <div class="info-box">
      <span class="info-box-icon bg-red"><i class="fa fa-cubes"></i></span>

      <div class="info-box-content">
        <span class="info-box-text">Total</span>
        <span class="info-box-text">Aset</span>
        <span class="info-box-number"><?php echo $jml_aset;?></span>
      </div>

    </div>
  </div>

  <!-- fix for small devices only -->
  <div class="clearfix visible-sm-block"></div>

  <div class="col-md-3 col-sm-6 col-xs-12">
    <div class="info-box">
      <span class="info-box-icon bg-yellow"><i class="fa fa-calendar-o"></i></span>

      <div class="info-box-content">
        <span class="info-box-text">Total</span>
        <span class="info-box-text">Tiket</span>
        <span class="info-box-number">1</span>
      </div>

    </div>
  </div>

  <div class="col-md-3 col-sm-6 col-xs-12">
    <div class="info-box">
      <span class="info-box-icon bg-green"><i class="fa fa-calendar-check-o"></i></span>

      <div class="info-box-content">
        <span class="info-box-text">Total</span>
        <span class="info-box-text">Tiket Selesai</span>
        <span class="info-box-number">1</span>
      </div>
    </div>
  </div>






<script type="text/javascript">
</script>

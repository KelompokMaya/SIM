  </div><!-- /.content-wrapper -->


</div><!-- ./wrapper -->


<!-- Bootstrap 3.3.2 JS -->
<script src="<?php echo base_url('assets/AdminLTE-2.3.11/bootstrap/js/bootstrap.min.js'); ?>" type="text/javascript"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/AdminLTE-2.3.11/plugins/datatables/jquery.dataTables.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/AdminLTE-2.3.11/plugins/datatables/dataTables.bootstrap.min.js"'); ?>" type="text/javascript"></script>
<!-- CK Editor -->
<script src="<?php echo base_url('assets/AdminLTE-2.3.11/plugins/ckeditor/ckeditor.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/AdminLTE-2.3.11/plugins/ckeditor/config.js'); ?>" type="text/javascript"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/AdminLTE-2.3.11/plugins/slimScroll/jquery.slimscroll.min.js'); ?>" type="text/javascript"></script>
<!-- FastClick -->
<script src='<?php echo base_url('assets/AdminLTE-2.3.11/plugins/fastclick/fastclick.min.js'); ?>'></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/AdminLTE-2.3.11/dist/js/app.min.js'); ?>" type="text/javascript"></script>
<!-- Compress Image -->
<script type="text/javascript" src="<?php echo base_url('assets/admin/js/compressImage.js'); ?>"></script>
<!-- BaliBigHugTour Ajax -->
<script src="<?php echo base_url('assets/admin/js/ajax.js') ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/admin/js/ajax2.js') ?>" type="text/javascript"></script>
   </body>
</html>

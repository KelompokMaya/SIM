<script type="text/javascript">
   //window.location=<?php base_url('Login'); ?>;
   window.location='http://localhost/SIM/Login';
</script>